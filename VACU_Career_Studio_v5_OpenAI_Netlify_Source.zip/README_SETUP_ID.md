# VACU Career Studio v5 — OpenAI AI Integration

Ini project website VACU plus **Netlify Serverless Function** untuk respons AI sungguhan. ZIP ini adalah **SOURCE PROJECT**, bukan ZIP HTML statis saja.

## PENTING: cara deploy
Netlify Drop/drag-and-drop statis mungkin tidak membangun Netlify Functions. Gunakan **deploy berbasis GitHub + Netlify build** atau Netlify CLI supaya endpoint `/api/career-ai` tersedia. Jika hanya upload HTML/ZIP sebagai berkas statis, halaman lain tampil tetapi AI akan menampilkan status "Fungsi AI belum terpasang".

1. Buat repository GitHub (private direkomendasikan). Upload SELURUH isi folder project, **termasuk `netlify/functions/career-ai.mjs` dan `netlify.toml`**. Jangan mengunggah file .env dengan secret.
2. Masuk ke Netlify > Add new project > Import an existing project > GitHub > pilih repository tadi. Atur `Publish directory` menjadi **public**; Netlify otomatis mengikuti `netlify.toml` dengan `npm run build`.
3. Buka Netlify > Project configuration > Environment variables > Add a variable:
   - `OPENAI_API_KEY` = secret API key dari platform.openai.com (disimpan di Netlify, BUKAN HTML)
   - `VACU_AI_ACCESS_CODE` = kode akses buatanmu yang sulit ditebak, minimal 16 karakter, hanya dibagi dengan pemilik demo
   - `VACU_AI_MODEL` = `gpt-6-luna` (opsional; model dapat diubah sesuai akses API)
   Scope harus mencakup `Functions` (default scope All juga cukup).
4. Trigger **new deploy** setelah mengatur environment variables.
5. Buka `https://<nama-project>.netlify.app/api/career-ai` di browser. Respons JSON harus memuat `"configured":true`. Jika 404, Netlify Function belum ter-deploy. Jika false, environment variables belum disetel.
6. Masuk ke VACU > AI > `Kode akses AI`, masukkan kode akses yang sama seperti `VACU_AI_ACCESS_CODE` (bukan OPENAI_API_KEY). Klik **Periksa koneksi**, lalu kirim pertanyaan. Jawaban AI kini diproses oleh OpenAI API.

## Keamanan dan biaya
- Jangan pernah menaruh OPENAI_API_KEY di HTML, JavaScript browser, README, GitHub, atau kirim ke chat.
- Aplikasi tidak mengirim profil/biodata otomatis ke AI; hanya isi chat dan nama target posisi.
- API OpenAI memiliki billing sendiri, terpisah dari langganan ChatGPT. Tetapkan budget & usage limits di dashboard API.
- `VACU_AI_ACCESS_CODE` adalah gerbang demo sederhana, bukan sistem login pengguna. Ada limit ringan per instance. Untuk dipublikasikan secara luas, perlu autentikasi pengguna, rate-limiting database, dan monitoring biaya.
- Kesempatan magang di VACU tetap contoh simulasi, bukan lowongan aktif.
- Jika fungsi belum dikonfigurasi, VACU tetap bisa dipakai untuk latihan offline; hanya AI live yang tidak dapat menjawab.

## Struktur
- `public/index.html`: aplikasi VACU iOS/iPad/Desktop
- `public/assets`: avatar + listening audio
- `public/sw.js`: PWA caching static files (requests /api excluded)
- `netlify/functions/career-ai.mjs`: OpenAI Responses API proxy with server-stored key
- `netlify.toml`: build and function routing
- `package.json`: simple build command

## Tes lokal
`npm install` (tanpa dependency) lalu `npx netlify dev` jika Netlify CLI tersedia dan variabel environment terpasang.
Browser file:// hanya menjalankan UI, bukan Netlify Functions.
