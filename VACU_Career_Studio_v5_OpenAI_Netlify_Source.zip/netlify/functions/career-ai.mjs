import { timingSafeEqual } from 'node:crypto';

const headers = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
};
const reply = (status, body) => new Response(JSON.stringify(body), { status, headers });
const requests = new Map(); // soft limit per warm instance; production needs durable limiter/auth

function matchesSecret(actual, expected) {
  if (!actual || !expected) return false;
  const a = Buffer.from(actual);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
export default async function careerAI(request) {
  if (request.method === 'GET') {
    const configured = Boolean(process.env.OPENAI_API_KEY && process.env.VACU_AI_ACCESS_CODE);
    return reply(200, {
      service: 'VACU OpenAI Career Assistant',
      configured,
      message: configured
        ? 'Server configured. Enter your VACU access code to send messages.'
        : 'Set OPENAI_API_KEY and VACU_AI_ACCESS_CODE in Netlify environment variables, then redeploy.',
    });
  }
  if (request.method !== 'POST') return reply(405, { error: 'Method not allowed' });
  const key = process.env.OPENAI_API_KEY;
  const secret = process.env.VACU_AI_ACCESS_CODE;
  if (!key || !secret) return reply(503, { error: 'VACU AI belum dikonfigurasi di Netlify. Tambahkan API key dan kode akses di pengaturan server.' });
  const origin = request.headers.get('origin');
  const host = request.headers.get('host');
  if (origin && host) {
    try { if (new URL(origin).host !== host) return reply(403, { error: 'Origin tidak diizinkan.' }); }
    catch { return reply(403, { error: 'Origin tidak valid.' }); }
  }
  if (!matchesSecret(request.headers.get('x-vacu-access-code'), secret)) return reply(401, { error: 'Kode akses VACU salah. Masukkan kode yang ditentukan di Netlify, bukan API key OpenAI.' });
  const ip = (request.headers.get('x-nf-client-connection-ip') || request.headers.get('x-forwarded-for') || 'unknown').split(',')[0].trim();
  const now = Date.now();
  if (requests.size > 1000) for (const [k,v] of requests) if (now-v.since>60_000) requests.delete(k);
  const r = requests.get(ip) || { since: now, count: 0 };
  if (now-r.since>60_000) { r.since=now; r.count=0; }
  r.count++;
  requests.set(ip,r);
  if (r.count>10) return reply(429,{error:'Batas permintaan tercapai. Coba lagi beberapa saat.'});
  if (Number(request.headers.get('content-length')||0)>13000) return reply(413,{error:'Pesan terlalu panjang.'});
  let parsed;
  try { parsed = await request.json(); } catch { return reply(400, { error: 'Data pesan tidak valid.' }); }
  const raw = parsed?.messages;
  if (!Array.isArray(raw) || raw.length<1 || raw.length>12) return reply(400,{error:'Riwayat chat tidak valid.'});
  const messages = [];
  for (const msg of raw) {
    if (msg?.role !== 'user' && msg?.role !== 'assistant') return reply(400,{error:'Peran pesan tidak valid.'});
    if (typeof msg.content !== 'string' || msg.content.length>1800) return reply(400,{error:'Pesan tidak valid atau terlalu panjang.'});
    messages.push({role: msg.role, content: msg.content});
  }
  if (messages[messages.length-1].role !== 'user') return reply(400,{error:'Pertanyaan terakhir harus dari pengguna.'});
  const role=typeof parsed.targetRole==='string'?parsed.targetRole.slice(0,80).replace(/[\r\n]/g,' '):'Intern';
  const instructions=`You are VACU Career Buddy, a supportive Indonesian-first internship preparation and skills coach. Respond in conversational Indonesian (unless the user requests English). Target internship role: ${role}. Help students with realistic skills simulations (Excel, accounting, writing, CVs, interview practice) and career planning. Do not claim you are the ChatGPT consumer app; you are an OpenAI-powered assistant inside VACU. VACU is a learning prototype, not a verified recruiter. Never claim jobs, salaries, eligibility, employer partnerships or matching percentages are real. Explain that real vacancies and immigration/visa requirements must be verified on official employer/government sites. Do not promise placement or accredited certifications. For CV and interview tips, do not invent user experience. Keep responses concise, actionable, and accurate. Do not request sensitive personal data. Invite further practice when helpful.`;
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),20000);
  try {
    const api=await fetch('https://api.openai.com/v1/responses',{
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},
      body:JSON.stringify({model:process.env.VACU_AI_MODEL||'gpt-6-luna',instructions,input:messages,max_output_tokens:850,store:false}),
      signal:controller.signal,
    });
    const data=await api.json().catch(()=>null);
    if (!api.ok) {
      if (api.status===401 || api.status===403) return reply(502,{error:'API key OpenAI ditolak. Periksa pengaturan di Netlify.'});
      if (api.status===429) return reply(429,{error:'Batas pemakaian OpenAI atau kredit API tercapai. Cek billing dan rate limits.'});
      return reply(502,{error:'OpenAI tidak dapat memproses permintaan. Periksa model, akses akun API, dan billing.'});
    }
    const output=(data?.output||[]).flatMap(item=>(item?.content||[]).filter(p=>p?.type==='output_text').map(p=>p.text)).join('\n').trim();
    if (!output) return reply(502,{error:'Respons AI kosong. Silakan coba lagi.'});
    return reply(200,{reply:output.slice(0,6000),provider:'OpenAI API'});
  } catch (e) {
    return reply(504,{error:e.name==='AbortError'?'Respons AI melebihi batas waktu. Coba pertanyaan lebih singkat.':'Tidak dapat menghubungi server OpenAI.'});
  } finally { clearTimeout(timeout); }
}
